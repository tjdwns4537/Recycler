package com.example.recycler.Activity;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.widget.ListView;

import com.example.recycler.Adapter.ListViewAdapter;
import com.example.recycler.BearItem;
import com.example.recycler.R;

public class ListViewActivity extends AppCompatActivity {

    private ListView listview = null;
    private ListViewAdapter adapter = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_community);

        listview = (ListView) findViewById(R.id.listview);
        adapter = new ListViewAdapter();

        //Adapter 안에 아이템의 정보 담기
        adapter.addItem(new BearItem("1", "글작성", R.drawable.ic_launcher_background));
        adapter.addItem(new BearItem("2", "글작성", R.drawable.ic_launcher_foreground));
        adapter.addItem(new BearItem("3", "글작성", R.drawable.ic_settings));
        adapter.addItem(new BearItem("4", "글작성", R.drawable.ic_settings));
        adapter.addItem(new BearItem("5", "글작성", R.drawable.ic_settings));
        adapter.addItem(new BearItem("6", "글작성", R.drawable.ic_settings));
        adapter.addItem(new BearItem("7", "글작성", R.drawable.ic_settings));
        adapter.addItem(new BearItem("8", "글작성", R.drawable.ic_settings));

        //리스트뷰에 Adapter 설정
        listview.setAdapter(adapter);
    }




}